package Tripledes;

public class EncryptionRounds {

	public static String EncryptionRounds16(String[] L, String[] R, String Key)
	{  String expanded;
	    String[] XORString;
	    String SBoxedString;
	    String finalstring;
		for(int i=0;i<15;i++)
		{
            //Expansion of right 32 bit string to 48 bit string
            expanded = Functions.Expansion(R[i]);
            
            //XORing the expanded string and 48 bit Key
            XORString = Functions.XOR(expanded,Key);
            
            //Getting Rows & Columns for SBoxes 
            SBoxedString = Functions.SBox(XORString);
            
            //XORing Left and Right halves
            R[i+1] = Functions.leftrightXOR(L[i],SBoxedString);
            
            //Storing right half to the next left half
            L[i+1] = R[i];		
		}
		String temp = L[15];
		L[15] = R[15];
		R[15] = temp;
		finalstring = L[15] + R[15];
		finalstring = Functions.finalpermutation(finalstring);
		return finalstring;
	}
}
