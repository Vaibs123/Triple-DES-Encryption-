package Tripledes;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;
import javax.swing.filechooser.FileNameExtensionFilter;


public class TripleDes {
	
public static void main(String[] args) throws IOException {  
    JFrame 				f					=	new JFrame("Triple DES"); 
    final JTextArea 	encryptfield		=	new JTextArea();  
    final JTextArea 	encryptdonefield	=	new JTextArea();  
    JButton 			encryptbutton		=	new JButton("Encrypt String"); 
    JLabel 				encryptlabel 		=	new JLabel("Enter the String to be encrypted here:");  
    JLabel 				encryptdonelabel 	=	new JLabel("Encrypted String:");  
    final JTextArea 	decryptfield		=	new JTextArea();  
    JLabel 				decryptlabel 		=	new JLabel("Decrypted String:");
    JButton 			decryptbutton		=	new JButton("Decrypt String"); 
    JButton 			openfile		=	new JButton("Import file"); 



  //  encryptdonefield.setVisible(true);
    
    encryptlabel.setBounds(50,20, 300,30);  
    decryptlabel.setBounds(50,340, 300,30);  
    encryptlabel.setFont(encryptlabel.getFont().deriveFont(15.0f)); 
    decryptlabel.setFont(encryptlabel.getFont().deriveFont(15.0f));
 
    
    encryptbutton.setBounds(750,320,195,30); 
    openfile.setBounds(570,320,160,30);
    encryptdonelabel.setBounds(1000,20, 300,30);
    encryptdonelabel.setFont(encryptlabel.getFont().deriveFont(15.0f));
    
  //  encryptdonefield.setBounds(1000,50, 350,530);
    decryptbutton.setBounds(1150,600,195,30);
   // decryptfield.setBounds(50,375, 900,250);
    
    Border border = BorderFactory.createLineBorder(Color.BLACK);
    encryptfield.setBorder(BorderFactory.createCompoundBorder(border,
            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
    encryptdonefield.setBorder(BorderFactory.createCompoundBorder(border,
            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
    decryptfield.setBorder(BorderFactory.createCompoundBorder(border,
            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
    
    
    JScrollPane scroll1 = new JScrollPane (encryptfield, 
    		   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    scroll1.setBounds(50,50, 900,250);
    encryptfield.setLineWrap(true);
    
    JScrollPane scroll2 = new JScrollPane (encryptdonefield, 
 		   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
 scroll2.setBounds(1000,50, 350,530);
 encryptdonefield.setLineWrap(true);
 
 JScrollPane scroll3 = new JScrollPane (decryptfield, 
		   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
scroll3.setBounds(50,375, 900,250);
decryptfield.setLineWrap(true);



		


     

    String[] leftkey48bits = new String[3];
    //String[] rightkey8bits;
    String[] timeStamp = new String[3];
    int t = 0;
    while(t<3)
    {
    	
    	//GENERATING KEY - TIMESTAMP
        timeStamp[t] 	= 	new SimpleDateFormat("HHmmss").format(new java.util.Date());
    	
        //MAKING TIMESTAMP INTO 56 BIT
        timeStamp[t] = Functions.appendtimestamp(timeStamp[t]);
        
        //CONVERTING TIMESTAMP TO BINARY AND DIVIDING INTO LEFT AND RIGHT KEYS
        // 48 BIT LEFT KEY
        leftkey48bits[t] = Functions.dividetimestamp(timeStamp[t],1);
        // 8 BIT RIGHT KEY
        //rightkey8bits = Functions.dividetimestamp(timeStamp,2);	
        t++;
    }
   

	
	
	 openfile.addActionListener(new ActionListener()
	 {  
		 public void actionPerformed(ActionEvent e)
		 {  
			 JFileChooser fileChooser = new JFileChooser();
			    FileNameExtensionFilter filter = new FileNameExtensionFilter(
			            "Text Files(*.txt)", "txt");
			    fileChooser.setFileFilter(filter);
			    fileChooser.setCurrentDirectory(new File(System
			            .getProperty("user.home")));
			    int result = fileChooser.showOpenDialog(null);
			    if (result == JFileChooser.APPROVE_OPTION) {
			        File selectedFile = fileChooser.getSelectedFile();
			        BufferedReader br = null;
			        try {
			            br = new BufferedReader(new FileReader(selectedFile));
			            StringBuilder sb = new StringBuilder();
			            String line = br.readLine();

			            while (line != null) {
			                sb.append(line);
			                sb.append(System.lineSeparator());
			                line = br.readLine();
			            }
			            String all = sb.toString();
			            encryptfield.setText(all);
			        }catch(Exception e1){
			            e1.printStackTrace();
			        }finally {
			            try {
			                br.close();
			            } catch (IOException ex) {
			                Logger.getLogger(TripleDes.class.getName()).log(Level.SEVERE, null, ex);
			            }
			        }
			    }
		 }
		     
	 });  
    //ENCRYPTING
    encryptbutton.addActionListener(new ActionListener(){  
public void actionPerformed(ActionEvent e){  
	long startTime = System.nanoTime();
	
		String text = encryptfield.getText();
		
	    int length = text.length();
	    String[] L = new String[16];
	    String[] R = new String[16];
	    //String result;
	    String finalstring = "";
	    
    	//CHECKING IF TEXTFIELD CONTAINS 0 BITS
        if (length == 0)
        {
        	JOptionPane.showMessageDialog(null, "Please enter a string", "Nothing Inside", JOptionPane.ERROR_MESSAGE);            
        }/*
        //CHECKING IF THE TEXTFIELD CONTAINS MORE THAN 64 BIT
        else if (length > 8)
        {
        	JOptionPane.showMessageDialog(null, "Lot of characters", "String too long", JOptionPane.ERROR_MESSAGE);
        }*/
        //ALGORITHM STEPS
        else 
        {
	        	int padding;
	        	int l;
	        	String[] TextArray;
	        	//FINDING OUT IF THE STRING NEEDS TO BE PADDED WITH ZEROS
	        	//IF YES THEN HOW MUCH
	        	if (length % 8 != 0)
	        	{
	        		l = length / 8;
	        		padding = length - (l)*8;
	        		padding = 8-padding;
	            	//PADDING THE STRING WITH ZEROS
	            	text = Functions.paddingzero(text, padding);   
	            	TextArray = new String[l+1];
	            	TextArray = Functions.divideStringintoArray(text,l+1);
	        	}   	
	        	//IF NO THEN NO NEED TO DO PADDING
	        	else 
	        	{
	        		//NO NEED TO PAD IN THIS ONE
	        		l = length / 8;
	        		padding = length - (l)*8;
	        		TextArray = new String[l];
	        		TextArray = Functions.divideStringintoArray(text,l);
	        	}
	        	
	        	int lengtharray= TextArray.length;
	        	int i = 0;
	        	int count = 0;
	        	while(count < 3)
	        	{
	        	while(i < lengtharray)
	        	{
	        		//Making it into 8bit string
	        		TextArray[i] = Functions.eightbitstring(TextArray[i]);
	        		
	        		//CONVERTING THE STRING TO 64 BIT
	        		TextArray[i] = Functions.convertto64bit(TextArray[i]);
	        		TextArray[i] = Functions.finalpermutation(TextArray[i]);
	        		
	        		//DIVIDING THE STRING INTO TWO HALVES
	        		L[0] 	 	= Functions.dividehalvesdecruptionmethod(TextArray[i],1);
	            	R[0] 		= Functions.dividehalvesdecruptionmethod(TextArray[i],2);
	              //  result 		= Functions.dividehalvesdecruptionmethod(TextArray[i],3);
	        		
	              /*//MAKING THE STRING INTO 8 BIT AND REVERSING THE STRING - PERMUTATION
	        		text = Functions.reversepermutation(text);
	            	//CONVERTING THE STRING TO 64 BIT BINARY AND DIVIDING THE STRING INTO TWO HALVES
	        		L[0] 	 	= Functions.dividehalves(text,1);
	            	R[0] 		= Functions.dividehalves(text,2);
	                result 		= Functions.dividehalves(text,3);*/
	                
	                
	                
	                //UNDERGOES 16 ENCRYPTION ROUNDS
	                String tempstring =  EncryptionRounds.EncryptionRounds16(L, R, leftkey48bits[count]);
	                finalstring = finalstring + tempstring;
	                
	                i++;
	        		
	        		}
	        	count++;
	        	}  
	        	//FINAL ENCRYPTED STRING IS DISPLAYED
	        	encryptdonefield.setText(finalstring.toString() + "-" + padding + "-");
	        	long endTime = System.nanoTime();

	        	long duration = (endTime - startTime);
	        	System.out.println("Duration it took to encrypt = " + duration);
	        
        }
        }
    });  
  //DECRYPTING
    decryptbutton.addActionListener(new ActionListener(){  
    	public void actionPerformed(ActionEvent e){  
    		long startTime = System.nanoTime();
    		String text1;
    		String text = encryptdonefield.getText();
    		int originallength = text.length();//CHECKING IF THE DECRYPT TEXTFIELD IS EMPTY
    		if (originallength == 0)
    		{
    			JOptionPane.showMessageDialog(null, "Encrypt string first", "Nothing to decrypt", JOptionPane.ERROR_MESSAGE);    		       	
    		}
    		else 
    		{
    			     //statements that may cause an exception
    				text1=text.substring(text.indexOf("-"),text.lastIndexOf("-"));
    	    		text=text.substring(0,text.indexOf("-"));
    	    		int pad = Integer.parseInt(text1);
    	    		int length1 = text.length();
    	    		
    	    		/*
    	    				//CONVERTING BINARY TO STRING
    	    				String[] ss = s.split( " " );
    		    		    StringBuilder sb = new StringBuilder();
    		    		    for ( int i = 0; i < ss.length; i++ ) 
    		    		    { 
    		    		        sb.append( (char)Integer.parseInt( ss[i], 2 ) );                                                                                                                                                        
    		    		    }  
    		    		    //REVERSING THE STRING AGAIN TO GET ORIGINAL STRING - REVERSE PERMUTATION
    		    		    String decryptedstring = Functions.reversepermutation(sb.toString());
    		    		    
    		    		    decryptfield.setText(decryptedstring);*/
    	    				int n = length1/64;
    	    				String[] Array = new String[n];
    	    			 //   String result;
    	    			    String finalstring = "";
    	    				Array = Functions.divideStringintoDecryptArray(text, n);
    	    				int i = 0;
    	    				int count = 3;
    	    				while(count > 0)
    	    				{
    	    				while(i < Array.length)
    	    				{
    	    					
    	    					Array[i] = Functions.finalpermutation(Array[i]);
    	        			  	String[] L = new String[16];
    	        			    String[] R = new String[16];
    	    	    			L[0] 	 	= Functions.dividehalvesdecruptionmethod(Array[i],1);
    	    	            	R[0] 		= Functions.dividehalvesdecruptionmethod(Array[i],2);
    	    	                //result 		= Functions.dividehalvesdecruptionmethod(Array[i],3);
    	    	                //System.out.println("text = " + text + " " + text.length());
    	    	                // System.out.println("L = " + L[0] + " " + L[0].length());
    	    	                //  System.out.println("R = " + R[0] + " " + R[0].length());
    	    	                
    	    	                String tempstring = DecryptionRounds.DecryptionRounds16(L, R, leftkey48bits[count-1]);
    	    	                
    	    	                tempstring = Functions.divideString(tempstring,8);
    	    	                finalstring = finalstring + tempstring;
    	    					i++;
    	    				}
    	    				count--;
    	    				}
    	    				
    	    				finalstring = finalstring.substring(0, finalstring.length() + pad);
    		                decryptfield.setText(finalstring.toString());
    		            	long endTime = System.nanoTime();

    			        	long duration = (endTime - startTime);
    			        	System.out.println("Duration it took to decrypt = " + duration);
    		
	    		   } 
    		}
    	    });  

    f.add(encryptbutton);
   // f.add(encryptfield);  
    f.add(encryptlabel);
    f.add(decryptbutton);
    //f.add(decryptfield); 
    f.add(encryptdonelabel);
    //f.add(encryptdonefield);
    f.add(decryptlabel);
    f.add(scroll1);
    f.add(scroll2);
    f.add(scroll3);
    f.add(openfile);
    
    
    f.setExtendedState(JFrame.MAXIMIZED_BOTH); 
    f.setLayout(null);  
    f.setVisible(true);   
}  

}  
