package Tripledes;

import java.util.Random;

public class Functions {
	
	public static String sixteenbit(String text)
	{
		int length = text.length();
    	//APPENDING RANDOM ALPHABETS AT THE END OF STRING TO MAKE IT 64 BIT
		while(length < 16)
	    {
	    	text = text + '0';
	    	length++;
	    }
		//REVERSING THE STRING
		StringBuilder myName = new StringBuilder(text);
		int i = 0;
		while(i<16)
		{
			myName.setCharAt(i, text.charAt(15-i));
			myName.setCharAt(15-i, text.charAt(i));
			i++;
		}
		return myName.toString();
	}
	
	public static String eightbitstring(String text)
	{
		int length = text.length();
        String alphabet 	= 	"abcdefghijklmnopqrstuvwxyz";
        Random rnd 			= 	new Random();

    	//APPENDING RANDOM ALPHABETS AT THE END OF STRING TO MAKE IT 64 BIT
		while(length < 8)
	    {
	    	char char1 = alphabet.charAt(rnd.nextInt(alphabet.length()));
	    	text = text + char1;
	    	length++;
	    }
		return text;
	}
	
	//PADDING WITH ZEROS
	public static String paddingzero(String text, int nopad)
	{
		//int length = text.length();
		int i = 0;
		while(i < nopad)
	    {
	    	char char1 = '0';
	    	text = text + char1;
	    	i++;
	    }
		return text;
	}
	
  //REVERSING THE STRING - PERMUTATION
	public static String reversepermutation(String text)
	{
		int length = text.length();
        String alphabet 	= 	"abcdefghijklmnopqrstuvwxyz";
        Random rnd 			= 	new Random();

    	//APPENDING RANDOM ALPHABETS AT THE END OF STRING TO MAKE IT 64 BIT
		while(length < 8)
	    {
	    	char char1 = alphabet.charAt(rnd.nextInt(alphabet.length()));
	    	text = text + char1;
	    	length++;
	    }
		//REVERSING THE STRING
		StringBuilder myName = new StringBuilder(text);
		int i = 0;
		while(i<8)
		{
			myName.setCharAt(i, text.charAt(7-i));
			myName.setCharAt(7-i, text.charAt(i));
			i++;
		}
		return myName.toString();
	}
	public static String finalpermutation(String text)
	{
	//	int length = text.length();
		//REVERSING THE STRING
		StringBuilder myName = new StringBuilder(text);
		int i = 0;
		while(i<64)
		{
			myName.setCharAt(i, text.charAt(63-i));
			myName.setCharAt(63-i, text.charAt(i));
			i++;
		}
		return myName.toString();
	}

	public static String convertto64bit(String text)
	{
		String result 	= new String();
	 //   String left 	= new String();
	  //  String right 	= new String();
    	int count			= 0;
    	byte[] bytes = text.getBytes();
    	StringBuilder binaryleft = new StringBuilder();
    	StringBuilder binaryright = new StringBuilder();
    	StringBuilder binaryresult = new StringBuilder();
    	for (byte b : bytes) 
    	{
    	    int val = b;
    	    if(count < 4)
    	    {
    	    	for (int i = 0; i < 8; i++) 
	    	    {
    	    		binaryleft.append((val & 128) == 0 ? 0 : 1);
    	    		binaryresult.append((val & 128) == 0 ? 0 : 1);
	    	        
	    	        val <<= 1;
	    	    }
    	    //	binaryleft.append(' ');
    	    //	binaryresult.append(' ');
    	        count++;
    	    }
    	    else
    	    {
    	    	for (int i = 0; i < 8; i++) 
	    	    {
    	    		binaryright.append((val & 128) == 0 ? 0 : 1);
    	    		binaryresult.append((val & 128) == 0 ? 0 : 1);
	    	        val <<= 1;
	    	    }
    	    //	binaryright.append(' ');
    	    //	binaryresult.append(' ');
    	        count++;
    	    }
    	}
    		result = binaryresult.toString();
        	return result;
    	
    	
	}
	
	//CONVERTING THE STRING TO BINARY AND DIVIDING THE STRING INTO TWO HALVES
	public static String dividehalves(String text, int a)
	{
		String result 	= new String();
	    String left 	= new String();
	    String right 	= new String();
    	int count			= 0;
    	byte[] bytes = text.getBytes();
    	StringBuilder binaryleft = new StringBuilder();
    	StringBuilder binaryright = new StringBuilder();
    	StringBuilder binaryresult = new StringBuilder();
    	for (byte b : bytes) 
    	{
    	    int val = b;
    	    if(count < 4)
    	    {
    	    	for (int i = 0; i < 8; i++) 
	    	    {
    	    		binaryleft.append((val & 128) == 0 ? 0 : 1);
    	    		binaryresult.append((val & 128) == 0 ? 0 : 1);
	    	        
	    	        val <<= 1;
	    	    }
    	    //	binaryleft.append(' ');
    	    	binaryresult.append(' ');
    	        count++;
    	    }
    	    else
    	    {
    	    	for (int i = 0; i < 8; i++) 
	    	    {
    	    		binaryright.append((val & 128) == 0 ? 0 : 1);
    	    		binaryresult.append((val & 128) == 0 ? 0 : 1);
	    	        val <<= 1;
	    	    }
    	    //	binaryright.append(' ');
    	    	binaryresult.append(' ');
    	        count++;
    	    }
    	}
    	if(a == 1)
    	{

        	left = binaryleft.toString();
        	return left;
    	}
    	else if(a==2)
    	{

        	right = binaryright.toString();
        	return right;
    	}
    	else 
    	{
    		result = binaryresult.toString();
        	return result;
    	}
    	
	   /* for (int i = 0; i < messChar.length; i++) 
	    {
	        result += Integer.toBinaryString(messChar[i]) + " ";
	        //LEFT HALF
	       if(i<32)
	       {
	    	   
	    	   
	    	   left[i] = Integer.toBinaryString(messChar[i]);
	       }
	       //RIGHT HALF
	       else
	       {
	    	   right[k] = Integer.toBinaryString(messChar[i]);
	    	   k++;
	       }
       }
	    if (a == 1)
	    {
	    	return left;
	    }
	    else if (a == 2)
	    {
	    	return right;
	    }
	    else if(a == 3) 
	    {
	    	ary[0] = result;
	    	return ary;
	    }
		//return result;
		return ary;*/
	}
	public static String dividehalvesdecruptionmethod(String text, int a)
	{
		final int mid = text.length() / 2; //get the middle of the String
		String[] parts = {text.substring(0, mid),text.substring(mid)};
		//System.out.println(parts[0]); //first part
		//System.out.println(parts[1]); //second part
		
    	if(a == 1)
    	{
        	return parts[0];
    	}
    	else if(a==2)
    	{
        	return parts[1];
    	}
    	else 
    	{
        	return text;
    	}
	}

    //MAKING TIMESTAMP INTO 56 BIT
	public static String appendtimestamp(String timeStamp)
	{
	        String alphabet 	= 	"abcdefghijklmnopqrstuvwxyz";
	        Random rnd 			= 	new Random();
			//int	   lengthTS 	=	timeStamp.length();

			//APPENDING RANDOM ALPHABET AT THE END OF THE TIMESTAMP TO MAKE IT 56 BIT
			
		    char char1 = alphabet.charAt(rnd.nextInt(alphabet.length()));
		    timeStamp = timeStamp + char1;
		   // lengthTS++;
			return timeStamp;
	}
	
    //CONVERTING TIMESTAMP TO BINARY AND DIVIDING INTO LEFT - 48 BIT AND RIGHT 8 BIT
	public static String dividetimestamp(String timeStamp, int a)
	{
	    String leftTS[] 	= 	new String[1];
	    String rightTS[] 	= 	new String[1];
	    int    count 		=	0;
    	byte[] bytes = timeStamp.getBytes();
		StringBuilder binary48timestamp = new StringBuilder();
		StringBuilder binary8timestamp = new StringBuilder();
    	for (byte b : bytes) 
    	{
    	    int val = b;
    	    if(count < 6)
    	    {
    	    	for (int i = 0; i < 8; i++) 
	    	    {
    	    		binary48timestamp.append((val & 128) == 0 ? 0 : 1);
	    	        
	    	        val <<= 1;
	    	    }
    	    	//binary48timestamp.append(' ');
    	    	count++;
    	    }
    	    else
    	    {
    	    	for (int i = 0; i < 8; i++) 
	    	    {
    	    		binary8timestamp.append((val & 128) == 0 ? 0 : 1);
	    	        
	    	        val <<= 1;
	    	    }
    	    	//binary8timestamp.append(' ');
    	    	count++;
    	    }
    	}
    	if(a ==1)
    	{
    		leftTS[0] = binary48timestamp.toString();
        	return leftTS[0];
    	}
    	else
    	{

        	rightTS[0] = binary8timestamp.toString();
        	return rightTS[0];
    	}
		/*char[] messChar1 = timeStamp.toCharArray();
	    for (int i = 0; i < messChar1.length; i++) 
	    {
	    	//resultTS contains the whole binary strings
	    	resultTS += Integer.toBinaryString(messChar1[i]) + " ";
	       //LEFT HALF - 48 BITS
	       if(i<48)
	       {
	    	//   leftTS[i] = Integer.toBinaryString(messChar1[i]);
	    	   leftTS[i] = Integer.toBinaryString(0x100 + messChar1[i]).substring(2);
	    	   System.out.println(leftTS[i]);
	       }
	       //RIGHT HALF - 8 BITS
	       else
	       {
	    	   rightTS[j] = Integer.toBinaryString(0x100 + messChar1[i]).substring(2);
	    	  // rightTS[j] = Integer.toBinaryString(messChar1[i]);
	    	   j++;
	       }
       }
	    //RETURNING THE WHOLE BINARY TIMESTAMP
	    if (a == 1)
	    {
	    	return leftTS;
	    }
	    else
	    {
	    	return rightTS;
	    }*/
	}
	
	//CREATING A FUNCTION WHERE THE 32 BIT STRING IS EXPANDED TO 48 BIT STRING
	public static String Expansion(String right32bitstring)
	{
		int k = 0;
		String[] temp32bitfourchars = new String[8]; 
		String final48bitsixchars  	= new String();
		final48bitsixchars = "";
		char[] temp48bitsinglechars = new char[48]; 
		right32bitstring = right32bitstring.replaceAll("\\[|\\]|,|\\s", "");
		char[] temp32bitsinglechars = new char[32];
		
		
		for (int i = 0; i < right32bitstring.length(); i++) 
		{
			 char c = right32bitstring.charAt(k);
			 temp32bitsinglechars[k] = c; 
			 k++;
		}
		k = 0;
		int count = 0;
		int tempnum = 0;

		String temp = "";
		//string divided into 4 bits of 8 blocks
		for(int i=0;i < right32bitstring.length();i++)
		{
			char c = right32bitstring.charAt(k);
			temp = temp + c;
			count++;
			if(count == 4)
			{
				temp32bitfourchars[tempnum] = temp;
				tempnum++;
				temp  = "";
				count = 0;
			}
			k++;
		}
		
		count = 0;
		k = 0;
		int l = 0;
		int first  = 0;
		for(int i = 0; i < 48; i++)
		{
			if(count == 0)
			{
				if(first == 0)
				{
					temp48bitsinglechars[l] = temp32bitsinglechars[31];
					final48bitsixchars = final48bitsixchars + temp48bitsinglechars[l];
					first++;
					l++;
					count++;
				}
				else
				{
					temp48bitsinglechars[l] = temp32bitsinglechars[k-1];
					final48bitsixchars = final48bitsixchars + temp48bitsinglechars[l];
					l++;
					count++;
				}
			}
			else if (count == 5)
			{
				if(i == 47)
				{
					temp48bitsinglechars[l] = temp32bitsinglechars[0];
					final48bitsixchars = final48bitsixchars + temp48bitsinglechars[l];
				}
				else 
				{
					temp48bitsinglechars[l] = temp32bitsinglechars[k];
					final48bitsixchars = final48bitsixchars + temp48bitsinglechars[l];
					count = 0;
					l++;
				}
				
			}
			else 
			{
				temp48bitsinglechars[l] =  temp32bitsinglechars[k];
				final48bitsixchars = final48bitsixchars + temp48bitsinglechars[l];
				count++;
				l++;
				k++;
				
			}
		}
/*		k = 0;
		count = 0;
		tempnum = 0;

		temp = "";

		//string divided into 6 bits of 8 blocks
		for(int i=0;i < temp48bitsinglechars.length;i++)
				{
					char c = temp48bitsinglechars[k];
					temp = temp + c;
					count++;
					if(count == 6)
					{
						final48bitsixchars[tempnum] = temp;
						tempnum++;
						temp  = "";
						count = 0;
					}
					k++;
				}*/
		//Returning Expanded string
		return final48bitsixchars;
	}	
	public static String[] XOR(String expanded, String leftkey48bits)
	{
		int length = expanded.length();
		String[] XORstring = new String[8];
		int XORedstring;
		String[] XORed = new String[1];
		XORed[0] = "";
		int i = 0;
		while(i < length)
		{
			XORedstring = expanded.charAt(i) ^ leftkey48bits.charAt(i);
			XORed[0] = XORed[0] + Integer.toString(XORedstring);
			i++;
		}
		
		//System.out.println(XORed[0] + " " + XORed[0].length());
		int count = 0;
		int number = 0;
		i = 0;
		XORstring[number] = "";
		while(i < XORed[0].length())
		{
			
			if(count == 6)
			{
				count = 0;
				number++;
				XORstring[number] = "";
				
			}
			else
			{
				XORstring[number] = XORstring[number] + XORed[0].charAt(i);
				//System.out.println(i);
				count++;
				i++;
			}
			
		}
		return XORstring;
	}
	
	//Converting 48 bit string to 32 bit string - SBoxing
	public static String SBox(String[] XORString)
	{
		String SBoxedString = new String(); 
		SBoxedString = "";
		int i = 0;
		//getting row numbers & column numbers and then calling SBoxTable Function
		while(i < XORString.length)
		{
			String row = "";
			String column = "";
			
			column = column + XORString[i].charAt(1);
			column = column + XORString[i].charAt(2);
			column = column + XORString[i].charAt(3);
			column = column + XORString[i].charAt(4);
			row = row + XORString[i].charAt(0);
			row = row + XORString[i].charAt(5);
			
			//Converting Binary to String
			int cols = Integer.parseInt(column, 2);
			int rows = Integer.parseInt(row, 2);
			
			//Calling SBox table
			SBoxedString = SBoxedString + SBoxtable(rows, cols);
			//System.out.println(SBoxedString[i]);
			i++;
		}
		return SBoxedString;
		
	}
	//Generating a Fixed SBoxtable 
	public static String SBoxtable(int a, int b)
	{
		int row = 4;
		int column = 16;
		String row1 = "0010 1100 0100 0001 0111 1010 1011 0110 1000 0101 0011 1111	1101 0000 1110 1001";				
		String row2 = "1110	1011	0010	1100	0100	0111	1101	0001	0101	0000	1111	1010	0011	1001	1000	0110";
		String row3 = "0100	0010	0001	1011	1010	1101	0111	1000	1111	1001	1100	0101	0110	0011	0000	1110";
		String row4 = "1011	1000	1100	0111	0001	1110	0010	1101	0110	1111	0000	1001	1010	0100	0101	0011";
		String[] splited1 = row1.split("\\s+");
		String[] splited2 = row2.split("\\s+");
		String[] splited3 = row3.split("\\s+");
		String[] splited4 = row4.split("\\s+");
		
		String matrix[][] = new String[row][column];
		int count = 0;
		for(int i = 0;i <=3;i++)
		{
			for(int j= 0; j <=15; j++)
			{
				if(count == 0)
				{
					matrix[i][j] = splited1[j];
					//System.out.print(splited1[j] + " ");
				}else if(count == 1)
				{
					matrix[i][j] = splited2[j];
					//System.out.print(splited2[j] + " ");
				}else if(count == 2)
				{
					matrix[i][j] = splited3[j];
					//System.out.print(splited3[j] + " ");
				}else if(count == 3)
				{
					matrix[i][j] = splited4[j];
					//System.out.print(splited4[j] + " ");
				}
			}
			count++;
		}
		return matrix[a][b];
		/*0010	1100	0100	0001	0111	1010	1011	0110	1000	0101	0011	1111	1101	0000	1110	1001
		1110	1011	0010	1100	0100	0111	1101	0001	0101	0000	1111	1010	0011	1001	1000	0110
		0100	0010	0001	1011	1010	1101	0111	1000	1111	1001	1100	0101	0110	0011	0000	1110
		1011	1000	1100	0111	0001	1110	0010	1101	0110	1111	0000	1001	1010	0100	0101	0011
*/
	}
	public static String leftrightXOR(String leftstring, String rightstring)
	{
		leftstring = leftstring.replaceAll("\\s","");
		//System.out.println("leftstring " + leftstring);
		//System.out.println("rightstring " + rightstring);
		int length = leftstring.length();
		int XORedstring;
		String XORed = new String();
		XORed = "";
		int i = 0;
		
		while(i < length)
		{
			XORedstring = leftstring.charAt(i) ^ rightstring.charAt(i);
			XORed = XORed + Integer.toString(XORedstring);
			i++;
		}
		
		//System.out.println("LR " + XORed + " " + XORed.length());
		return XORed;
	}
	
	public static String[] divideStringintoDecryptArray(String str, int n)
    {
		String[] Array = new String[n];
		int i = 0;
		int j =0;
		String finalstr = "";
			while(j<n*64)
			{
				finalstr = finalstr + str.charAt(j);
				j++;
				if(j%64 == 0)
				{
					Array[i] = finalstr;
					i++;
					finalstr = "";
				}
			}
		return Array;
    }
	
	public static String[] divideStringintoArray(String str, int n)
    {
		String[] Array = new String[n];
		int i = 0;
		int j =0;
		String finalstr = "";
			while(j<n*8)
			{
				finalstr = finalstr + str.charAt(j);
				j++;
				if(j%8 == 0)
				{
					Array[i] = finalstr;
					i++;
					finalstr = "";
				}
			}
		return Array;
    }
	
	//dividing the string into n number of parts & Converting it from Binary into String
	public static String divideString(String str, int n)
	    {
		   String finalstr = "";
	       int str_size = str.length();
	       int part_size;
	       
	       /* Calculate the size of parts to find the division points*/
	       part_size = str_size/n;
	       
	       for (int i = 0; i< str_size; i++)
	       {
	           if(i % part_size == 0 && i != 0) 
	           {
	              finalstr = finalstr + " ";
	           }
	           finalstr = finalstr + str.charAt(i); 
	       }
	       String[] singleBinaryArray = finalstr.toString().split("\\s");
           String finalResult = "";
           for (String string : singleBinaryArray) 
           {
        	   Character c = (char) Integer.parseInt(string, 2);
        	       finalResult += c.toString();
           }
           return finalResult;
	    }
	
}
